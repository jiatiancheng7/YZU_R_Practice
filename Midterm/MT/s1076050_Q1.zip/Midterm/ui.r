
library(shiny)

shinyUI(fluidPage(  
  titlePanel("Air Pollution"),  
  sidebarLayout(
    sidebarPanel(
      selectInput("type", "Choose a type:", 
                  choices =unique(x[,2]))      
    ),     
    mainPanel(
      
      plotOutput("BoxPlot")
    )
  )
))

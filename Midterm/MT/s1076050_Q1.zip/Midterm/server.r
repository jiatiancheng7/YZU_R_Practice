
library(shiny)
library(dplyr)
library(datasets)

shinyServer(function(input, output) {
  datasetInput <- reactive({
    x %>% filter(Type == input$type)
  })
  
  output$BoxPlot <- renderPlot({
    dataset = datasetInput()
    data1=t(dataset[,3:26])
    date=unique(dataset[,1])
    colnames(data1) = paste(date)
    boxplot(data1)
    
    
  }) 
})
